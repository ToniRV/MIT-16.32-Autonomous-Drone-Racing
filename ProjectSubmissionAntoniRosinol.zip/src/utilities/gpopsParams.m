function gpops_params = gpopsParams
%GPOPSPARAMS Returns params specific to gpops
gpops_params.N_gates = 1;
end

